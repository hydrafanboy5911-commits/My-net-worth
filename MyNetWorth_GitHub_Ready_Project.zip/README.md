# My Net Worth

A simple Android app for tracking assets, liabilities, and net worth.

## Build from your phone with GitHub

1. Create a GitHub repository named `MyNetWorth`.
2. Upload the contents of this project ZIP to the repository (not the ZIP file itself).
3. Make sure `.github/workflows/build-apk.yml` is present.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK**.
6. Tap **Run workflow**.
7. After the workflow finishes successfully, open the run and download the **MyNetWorth-debug-APK** artifact.
8. Extract the artifact and install `app-debug.apk` on your Android phone.

The workflow uses GitHub Actions to build the debug APK and upload it as an artifact.
