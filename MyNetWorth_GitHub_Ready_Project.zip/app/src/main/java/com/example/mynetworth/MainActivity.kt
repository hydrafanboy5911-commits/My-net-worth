package com.example.mynetworth

import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

data class Entry(var name: String, var amount: Double)

class MainActivity : AppCompatActivity() {
    private val assets = mutableListOf<Entry>()
    private val liabilities = mutableListOf<Entry>()
    private lateinit var assetList: LinearLayout
    private lateinit var liabilityList: LinearLayout
    private lateinit var totals: TextView
    private val prefs by lazy { getSharedPreferences("networth", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        load()
        refresh()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 40)
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "My Net Worth"
            textSize = 28f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)

        totals = TextView(this).apply {
            textSize = 20f
            setPadding(0, 18, 0, 28)
        }
        root.addView(totals)

        root.addView(sectionTitle("Assets"))
        val addAsset = Button(this).apply {
            text = "+ Add Asset"
            setOnClickListener { showEntryDialog(false, -1) }
        }
        root.addView(addAsset)
        assetList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(assetList)

        root.addView(sectionTitle("Liabilities"))
        val addLiability = Button(this).apply {
            text = "+ Add Liability"
            setOnClickListener { showEntryDialog(true, -1) }
        }
        root.addView(addLiability)
        liabilityList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(liabilityList)

        setContentView(scroll)
    }

    private fun sectionTitle(s: String) = TextView(this).apply {
        text = s
        textSize = 22f
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 20, 0, 8)
    }

    private fun money(v: Double): String =
        NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(v)

    private fun refresh() {
        assetList.removeAllViews()
        liabilityList.removeAllViews()
        assets.forEachIndexed { i, e -> addRow(assetList, e, false, i) }
        liabilities.forEachIndexed { i, e -> addRow(liabilityList, e, true, i) }

        val a = assets.sumOf { it.amount }
        val l = liabilities.sumOf { it.amount }
        totals.text = "Total Assets: ${money(a)}\nTotal Liabilities: ${money(l)}\n\nNet Worth: ${money(a-l)}"
    }

    private fun addRow(parent: LinearLayout, e: Entry, liability: Boolean, index: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 8)
        }
        val text = TextView(this).apply {
            text = "${e.name}\n${money(e.amount)}"
            textSize = 17f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        row.addView(text)

        val edit = Button(this).apply {
            text = "Edit"
            setOnClickListener { showEntryDialog(liability, index) }
        }
        row.addView(edit)

        val del = Button(this).apply {
            text = "Delete"
            setOnClickListener {
                if (liability) liabilities.removeAt(index) else assets.removeAt(index)
                save()
                refresh()
            }
        }
        row.addView(del)
        parent.addView(row)
    }

    private fun showEntryDialog(liability: Boolean, index: Int) {
        val old = if (index >= 0) (if (liability) liabilities[index] else assets[index]) else null
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 0)
        }
        val name = EditText(this).apply {
            hint = "Name"
            setText(old?.name ?: "")
        }
        val amount = EditText(this).apply {
            hint = "Amount (₹)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(if (old != null) old.amount.toString() else "")
        }
        box.addView(name)
        box.addView(amount)

        AlertDialog.Builder(this)
            .setTitle(if (index >= 0) "Edit" else "Add ${if (liability) "Liability" else "Asset"}")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = name.text.toString().trim()
                val a = amount.text.toString().toDoubleOrNull() ?: 0.0
                if (n.isNotEmpty() && a >= 0) {
                    if (index >= 0) {
                        val target = if (liability) liabilities else assets
                        target[index] = Entry(n, a)
                    } else {
                        if (liability) liabilities.add(Entry(n, a))
                        else assets.add(Entry(n, a))
                    }
                    save()
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun save() {
        prefs.edit()
            .putString("assets", JSONArray().apply {
                assets.forEach { put(JSONObject().apply {
                    put("name", it.name); put("amount", it.amount)
                }) }
            }.toString())
            .putString("liabilities", JSONArray().apply {
                liabilities.forEach { put(JSONObject().apply {
                    put("name", it.name); put("amount", it.amount)
                }) }
            }.toString())
            .apply()
    }

    private fun load() {
        fun read(key: String, target: MutableList<Entry>) {
            target.clear()
            val arr = JSONArray(prefs.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                target.add(Entry(o.getString("name"), o.getDouble("amount")))
            }
        }
        read("assets", assets)
        read("liabilities", liabilities)
    }
}
